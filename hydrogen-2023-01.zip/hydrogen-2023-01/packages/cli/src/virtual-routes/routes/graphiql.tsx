import {graphiqlLoader} from '@shopify/hydrogen';

export const loader = graphiqlLoader;
