#!/usr/bin/env node

import {runInit} from '@shopify/cli-hydrogen/commands/hydrogen/init';

runInit();
