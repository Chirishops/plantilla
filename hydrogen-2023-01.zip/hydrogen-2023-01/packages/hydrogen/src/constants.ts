export const STOREFRONT_REQUEST_GROUP_ID_HEADER =
  'Custom-Storefront-Request-Group-ID';
export const STOREFRONT_API_BUYER_IP_HEADER = 'Shopify-Storefront-Buyer-IP';
export const STOREFRONT_ID_HEADER = 'Shopify-Storefront-Id';
