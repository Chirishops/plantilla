---
'@shopify/cli-hydrogen': patch
---

Show available upgrades for CLI when creating new projects.
