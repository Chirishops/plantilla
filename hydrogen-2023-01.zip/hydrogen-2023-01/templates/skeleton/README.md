# Hydrogen template: Skeleton

This template seeds the `shopify hydrogen generate` command from the `hydrogen cli`.
